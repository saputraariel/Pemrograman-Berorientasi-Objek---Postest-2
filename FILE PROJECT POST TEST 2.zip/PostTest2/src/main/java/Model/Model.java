package Model;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Asus
 */

public class Model {
    // Properties
    private String nama;
    private String daerahAsal;
    private int tahunPembuatan;

    // Constructor
    public Model(String nama, String daerahAsal, int tahunPembuatan) {
        this.nama = nama;
        this.daerahAsal = daerahAsal;
        this.tahunPembuatan = tahunPembuatan;
    }

    // Getter & Setter
    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getDaerahAsal() {
        return daerahAsal;
    }

    public void setDaerahAsal(String daerahAsal) {
        this.daerahAsal = daerahAsal;
    }

    public int getTahunPembuatan() {
        return tahunPembuatan;
    }

    public void setTahunPembuatan(int tahunPembuatan) {
        this.tahunPembuatan = tahunPembuatan;
    }

    @Override
    public String toString() {
        return nama + " - " + daerahAsal + " (Tahun: " + tahunPembuatan + ")";
    }
}
