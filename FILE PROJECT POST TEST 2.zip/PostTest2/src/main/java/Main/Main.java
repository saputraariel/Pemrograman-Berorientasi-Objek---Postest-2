package Main;
import java.util.Scanner;
import Service.Service;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Asus
 */

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Service service = new Service();
        int pilihan;

        do {
            System.out.println("|=+=== Manajemen Alat Musik Tradisional ===+=|");
            System.out.println("1. Me");
            System.out.println("2. Tampilkan Semua");
            System.out.println("3. Edit Alat Musik");
            System.out.println("4. Hapus Alat Musik");
            System.out.println("5. Cari Alat Musik");
            System.out.println("0. Keluar");
            System.out.print("Pilih menu: ");
            pilihan = input.nextInt();
            input.nextLine();

            switch (pilihan) {
                case 1 -> service.tambahAlat();
                case 2 -> service.tampilkanAlat();
                case 3 -> service.editAlat();
                case 4 -> service.hapusAlat();
                case 5 -> service.cariAlat();
                case 0 -> System.out.println("Terima kasih!");
                default -> System.out.println("Pilihan tidak valid.");
            }
        } while (pilihan != 0);

        input.close();
    }
}
