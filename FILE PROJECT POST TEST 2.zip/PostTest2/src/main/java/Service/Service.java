package Service;
import java.util.ArrayList;
import java.util.Scanner;
import Model.Model;

public class Service {
    private ArrayList<Model> daftarAlat = new ArrayList<>();
    private Scanner input = new Scanner(System.in);

    // ✅ Constructor untuk menambahkan data awal
    public Service() {
        daftarAlat.add(new Model("Angklung", "Jawa Barat", 1938));
        daftarAlat.add(new Model("Gamelan", "Jawa Tengah", 1850));
        daftarAlat.add(new Model("Sasando", "Nusa Tenggara Timur", 1900));
        daftarAlat.add(new Model("Kolintang", "Sulawesi Utara", 1920));
    }

    // CREATE
    public void tambahAlat() {
        System.out.print("Nama alat musik : ");
        String nama = input.nextLine();
        System.out.print("Daerah asal : ");
        String daerah = input.nextLine();
        System.out.print("Tahun pembuatan : ");
        int tahun = input.nextInt();
        input.nextLine(); // clear buffer

        daftarAlat.add(new Model(nama, daerah, tahun));
        System.out.println("+= Data berhasil ditambahkan! =+");
    }

    // READ
    public void tampilkanAlat() {
        if (daftarAlat.isEmpty()) {
            System.out.println("+= Tidak ada data =+.");
            return;
        }
        System.out.println("Daftar Alat Musik:");
        for (int i = 0; i < daftarAlat.size(); i++) {
            System.out.println((i + 1) + ". " + daftarAlat.get(i));
        }
    }

    // UPDATE
    public void editAlat() {
        tampilkanAlat();
        System.out.print("Pilih nomor data yang akan diedit: ");
        int index = input.nextInt() - 1;
        input.nextLine(); // clear buffer

        if (index >= 0 && index < daftarAlat.size()) {
            System.out.print("Nama baru : ");
            String nama = input.nextLine();
            System.out.print("Daerah baru : ");
            String daerah = input.nextLine();
            System.out.print("Tahun baru : ");
            int tahun = input.nextInt();
            input.nextLine();

            daftarAlat.set(index, new Model(nama, daerah, tahun));
            System.out.println("✏️ Data berhasil diubah!");
        } else {
            System.out.println("❌ Nomor tidak valid.");
        }
    }

    // DELETE
    public void hapusAlat() {
        tampilkanAlat();
        System.out.print("Pilih nomor data yang akan dihapus: ");
        int index = input.nextInt() - 1;
        input.nextLine();

        if (index >= 0 && index < daftarAlat.size()) {
            daftarAlat.remove(index);
            System.out.println("🗑 Data berhasil dihapus!");
        } else {
            System.out.println("❌ Nomor tidak valid.");
        }
    }

    // SEARCH
    public void cariAlat() {
        System.out.print("Masukkan kata kunci pencarian: ");
        String keyword = input.nextLine().toLowerCase();
        boolean ditemukan = false;

        for (Model alat : daftarAlat) {
            if (alat.getNama().toLowerCase().contains(keyword) ||
                alat.getDaerahAsal().toLowerCase().contains(keyword)) {
                System.out.println("Ditemukan: " + alat);
                ditemukan = true;
            }
        }
        if (!ditemukan) {
            System.out.println("Data tidak ditemukan.");
        }
    }
}
