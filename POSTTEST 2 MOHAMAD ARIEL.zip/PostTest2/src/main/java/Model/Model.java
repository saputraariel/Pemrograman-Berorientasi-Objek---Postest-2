package Model;

public class Model {
    private String nama;
    private String daerahAsal;
    private int tahunPembuatan;

    public Model(String nama, String daerahAsal, int tahunPembuatan) {
        this.nama = nama;
        this.daerahAsal = daerahAsal;
        this.tahunPembuatan = tahunPembuatan;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getDaerahAsal() {
        return daerahAsal;
    }

    public void setDaerahAsal(String daerahAsal) {
        this.daerahAsal = daerahAsal;
    }

    public int getTahunPembuatan() {
        return tahunPembuatan;
    }

    public void setTahunPembuatan(int tahunPembuatan) {
        this.tahunPembuatan = tahunPembuatan;
    }

    @Override
    public String toString() {
        return nama + " - " + daerahAsal + " (Tahun: " + tahunPembuatan + ")";
    }
}
